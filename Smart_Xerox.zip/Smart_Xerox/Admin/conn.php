<?php
date_default_timezone_set("Asia/Calcutta");
$servername = "localhost";
$username = "root";
$password = "";
$database = "de";
$conn = mysqli_connect("localhost", "root", "", "de");
?> 
